﻿namespace oop_ödev_2.hafta_deneme_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Yaş = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.adTxt = new System.Windows.Forms.TextBox();
            this.adresTxt = new System.Windows.Forms.TextBox();
            this.yasTxt = new System.Windows.Forms.TextBox();
            this.mesaiTxt = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ad Soyad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Adres";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Yaş
            // 
            this.Yaş.AutoSize = true;
            this.Yaş.Location = new System.Drawing.Point(33, 185);
            this.Yaş.Name = "Yaş";
            this.Yaş.Size = new System.Drawing.Size(31, 16);
            this.Yaş.TabIndex = 2;
            this.Yaş.Text = "Yaş";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ünvan";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Mesai Saati";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(276, 349);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 63);
            this.button1.TabIndex = 5;
            this.button1.Text = "personel oluştur";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(127, 229);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(146, 24);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // adTxt
            // 
            this.adTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.adTxt.Location = new System.Drawing.Point(127, 20);
            this.adTxt.Name = "adTxt";
            this.adTxt.Size = new System.Drawing.Size(141, 22);
            this.adTxt.TabIndex = 7;
            this.adTxt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // adresTxt
            // 
            this.adresTxt.Location = new System.Drawing.Point(127, 62);
            this.adresTxt.Multiline = true;
            this.adresTxt.Name = "adresTxt";
            this.adresTxt.Size = new System.Drawing.Size(146, 86);
            this.adresTxt.TabIndex = 8;
            this.adresTxt.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // yasTxt
            // 
            this.yasTxt.Location = new System.Drawing.Point(127, 185);
            this.yasTxt.Name = "yasTxt";
            this.yasTxt.Size = new System.Drawing.Size(146, 22);
            this.yasTxt.TabIndex = 9;
            this.yasTxt.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // mesaiTxt
            // 
            this.mesaiTxt.Location = new System.Drawing.Point(127, 273);
            this.mesaiTxt.Name = "mesaiTxt";
            this.mesaiTxt.Size = new System.Drawing.Size(141, 22);
            this.mesaiTxt.TabIndex = 10;
            this.mesaiTxt.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(601, 79);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(208, 127);
            this.textBox5.TabIndex = 11;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 487);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.mesaiTxt);
            this.Controls.Add(this.yasTxt);
            this.Controls.Add(this.adresTxt);
            this.Controls.Add(this.adTxt);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Yaş);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Yaş;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox adTxt;
        private System.Windows.Forms.TextBox adresTxt;
        private System.Windows.Forms.TextBox yasTxt;
        private System.Windows.Forms.TextBox mesaiTxt;
        private System.Windows.Forms.TextBox textBox5;
    }
}

